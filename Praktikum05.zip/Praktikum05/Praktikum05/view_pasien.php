<?php
require_once 'dbkoneksi.php';

// Memeriksa apakah parameter 'id' ada dalam URL
if (!isset($_GET['id'])) {
    die("ID tidak ditemukan.");
}

$_id = $_GET['id'];

// Pastikan $_id adalah angka untuk menghindari SQL Injection
if (!is_numeric($_id)) {
    die("Invalid ID");
}

// Query untuk mengambil data pasien berdasarkan ID
$sql = "SELECT * FROM pasien WHERE id=?";
$st = $dbh->prepare($sql);
$st->execute([$_id]);
$row = $st->fetch();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pasien</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Detail Pasien</h2>
        <?php
        if ($row) {
            ?>
            <table class="table table-striped">
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                    </tr>
                    <tr>
                        <td>Kode</td>
                        <td><?= htmlspecialchars($row['kode']) ?></td>
                    </tr>
                    <tr>
                        <td>Nama Pasien</td>
                        <td><?= htmlspecialchars($row['nama']) ?></td>
                    </tr>
                    <tr>
                        <td>Tempat Lahir</td>
                        <td><?= htmlspecialchars($row['tmp_lahir']) ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td><?= htmlspecialchars($row['tgl_lahir']) ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?= htmlspecialchars($row['gender']) ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?= htmlspecialchars($row['alamat']) ?></td>
                    </tr>
                    <tr>
                        <td>Kelurahan ID</td>
                        <td><?= htmlspecialchars($row['kelurahan_id']) ?></td>
                    </tr>
                </tbody>
            </table>
            <?php
        } else {
            echo "<div class='alert alert-danger'>Data tidak ditemukan.</div>";
        }
        ?>
        <a href="list_pasien.php" class="btn btn-secondary">Kembali</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>