<?php
class mahasiswa {
    public $nama;
    public $nim;
    public $matkul;
    public $nilai;

    public function __construct($nama, $nim, $matkul, $nilai) {
        $this->nama = $nama;
        $this->nim = $nim;
        $this->matkul = $matkul;
        $this->nilai = $nilai;
    }

    public function kelulusan() {
        return ($this->nilai >= 60) ? "lulus" : "tidak lulus";
    }

    public function grade(){
        if ($this->nilai >= 85) {
            return "A";
        }
        elseif ($this->nilai >= 70) {
            return "B";
        }
        elseif ($this->nilai >= 55) {
            return "C";
        }
        elseif ($this->nilai >= 40) {
            return "C";
        }
        else {
            return "D";
        }
        }
        }
?>