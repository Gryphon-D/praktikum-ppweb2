<?php
require_once 'dbkoneksi.php';

// Menangkap data yang dikirimkan melalui form
$_kode = $_POST['kode'] ?? '';
$_nama = $_POST['nama'] ?? '';
$_tmp_lahir = $_POST['tmp_lahir'] ?? '';
$_tgl_lahir = $_POST['tgl_lahir'] ?? '';
$_gender = $_POST['gender'] ?? '';
$_email = $_POST['email'] ?? '';
$_alamat = $_POST['alamat'] ?? '';
$_kelurahan_id = $_POST['kelurahan_id'] ?? '';
$_proses = $_POST['proses'] ?? '';

// Validasi input
if (empty($_kode) || empty($_nama) || empty($_tmp_lahir) || empty($_tgl_lahir) || empty($_gender) || empty($_email) || empty($_alamat) || empty($_kelurahan_id)) {
    die("Semua field harus diisi.");
}

// array data
$ar_data = [
    $_kode,
    $_nama,
    $_tmp_lahir,
    $_tgl_lahir,
    $_gender,
    $_email,
    $_alamat,
    $_kelurahan_id
];

try {
    if ($_proses == "Simpan") {
        // Data baru
        $sql = "INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, email, alamat, kelurahan_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    } else if ($_proses == "Update") {
        // Menambahkan ID pasien untuk update
        $ar_data[] = $_POST['idedit'] ?? null; // ? 8
        $sql = "UPDATE pasien SET kode=?, nama=?, tmp_lahir=?, tgl_lahir=?, gender=?, email=?, alamat=?, kelurahan_id=? WHERE id=?";
    }

    if (isset($sql)) {
        $st = $dbh->prepare($sql);
        $st->execute($ar_data);
    }

    // Redirect setelah berhasil
    header('Location: pasien.php');
    exit; // Pastikan untuk menghentikan eksekusi script setelah redirect
} catch (PDOException $e) {
    // Menangani kesalahan
    echo "Error: " . $e->getMessage();
}
?> 