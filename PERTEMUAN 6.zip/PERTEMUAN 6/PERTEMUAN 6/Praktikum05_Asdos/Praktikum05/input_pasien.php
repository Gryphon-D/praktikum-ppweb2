<?php
require_once 'dbkoneksi.php';
$row = [
    'kode' => '', 'nama' => '', 'tmp_lahir' => '', 'tgl_lahir' => '',
    'gender' => '', 'email' => '', 'alamat' => '', 'kelurahan_id' => ''
];
$idedit = $_GET['idedit'] ?? '';
$btnLabel = 'Simpan';

if (!empty($idedit)) {
    $sql = "SELECT * FROM pasien WHERE id=?";
    $st = $dbh->prepare($sql);
    $st->execute([$idedit]);
    $row = $st->fetch();
    $btnLabel = 'Update';
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Form Pasien</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Form Pasien</h2>
    <form action="proses_pasien.php" method="POST">
        <input type="hidden" name="idedit" value="<?= $idedit ?>">
        <div class="form-group">
            <label>Kode</label>
            <input name="kode" type="text" class="form-control" value="<?= $row['kode'] ?>">
        </div>
        <div class="form-group">
            <label>Nama</label>
            <input name="nama" type="text" class="form-control" value="<?= $row['nama'] ?>">
        </div>
        <div class="form-group">
            <label>Tempat Lahir</label>
            <input name="tmp_lahir" type="text" class="form-control" value="<?= $row['tmp_lahir'] ?>">
        </div>
        <div class="form-group">
            <label>Tanggal Lahir</label>
            <input name="tgl_lahir" type="date" class="form-control" value="<?= $row['tgl_lahir'] ?>">
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="gender" class="form-control">
                <option value="L" <?= $row['gender'] == 'L' ? 'selected' : '' ?>>Laki-laki</option>
                <option value="P" <?= $row['gender'] == 'P' ? 'selected' : '' ?>>Perempuan</option>
            </select>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input name="email" type="email" class="form-control" value="<?= $row['email'] ?>">
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <input name="alamat" type="text" class="form-control" value="<?= $row['alamat'] ?>">
        </div>
        <div class="form-group">
            <label>Kelurahan ID</label>
            <input name="kelurahan_id" type="text" class="form-control" value="<?= $row['kelurahan_id'] ?>">
        </div>
        <button name="proses" value="<?= $btnLabel ?>" type="submit" class="btn btn-success"><?= $btnLabel ?></button>
    </form>
</div>
</body>
</html>
