<?php
include 'db_koneksi.php';

// Delete
if (isset($_GET['hapus'])) {
    $stmt = $dbh->prepare("DELETE FROM pasien WHERE id = ?");
    $stmt->execute([$_GET['hapus']]);
    header('Location: data_pasien.php');
    exit;
}

// Insert / Update
if ($_POST['proses'] == 'Simpan') {
    $stmt = $dbh->prepare("INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, email, alamat) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['kode'], $_POST['nama'], $_POST['tmp_lahir'], $_POST['tgl_lahir'], $_POST['gender'], $_POST['email'], $_POST['alamat']]);
} elseif ($_POST['proses'] == 'Update') {
    $stmt = $dbh->prepare("UPDATE pasien SET kode=?, nama=?, tmp_lahir=?, tgl_lahir=?, gender=?, email=?, alamat=? WHERE id=?");
    $stmt->execute([$_POST['kode'], $_POST['nama'], $_POST['tmp_lahir'], $_POST['tgl_lahir'], $_POST['gender'], $_POST['email'], $_POST['alamat'], $_POST['id']]);
}
header('Location: data_pasien.php');
