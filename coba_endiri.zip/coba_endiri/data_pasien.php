<?php
include 'db_koneksi.php';
$stmt = $dbh->query("SELECT p.*, k.nama AS nama_kelurahan FROM pasien p LEFT JOIN kelurahan k ON p.kelurahan_id = k.id");
?>
<a href="form_pasien.php">Tambah Pasien</a>
<table border="1">
<tr><th>Kode</th><th>Nama</th><th>Kelurahan</th><th>Aksi</th></tr>
<?php while ($row = $stmt->fetch()) { ?>
<tr>
<td>                    <?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['kode']) ?></td>
                        <td><?= htmlspecialchars($row['nama']) ?></td>
                        <td><?= htmlspecialchars($row['tmp_lahir']) ?></td>
                        <td><?= htmlspecialchars($row['tgl_lahir']) ?></td>
                        <td><?= htmlspecialchars($row['gender']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['alamat']) ?></td>
                        <td><?= htmlspecialchars($row['nama_kelurahan']) ?></td>
    <td>
        <a href="form_pasien.php?id=<?= $row['id'] ?>">Edit</a> |
        <a href="proses_pasien.php?hapus=<?= $row['id'] ?>" onclick="return confirm('Yakin hapus?')">Delete</a>
    </td>
</tr>
<?php } ?>
</table>
