<?php
include 'db_koneksi.php';
$edit = false;
if (isset($_GET['id'])) {
    $edit = true;
    $stmt = $dbh->prepare("SELECT * FROM pasien WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $row = $stmt->fetch();
}
?>
<form method="POST" action="proses_pasien.php">
    <input type="hidden" name="id" value="<?= $edit ? $row['id'] : '' ?>"> Kode: 
    <input type="text" name="kode" value="<?= $edit ? $row['kode'] : '' ?>"><br>
    Nama: <input type="text" name="nama" value="<?= $edit ? $row['nama'] : '' ?>"><br>
    Tempat Lahir: <input type="text" name="tmp_lahir" value="<?= $edit ? $row['tmp_lahir'] : '' ?>"><br>
    Tgl Lahir: <input type="date" name="tgl_lahir" value="<?= $edit ? $row['tgl_lahir'] : '' ?>"><br>
    Gender:
    <input type="radio" name="gender" value="L" <?= $edit && $row['gender']=='L' ? 'checked' : '' ?>> Laki-Laki
    <input type="radio" name="gender" value="P" <?= $edit && $row['gender']=='P' ? 'checked' : '' ?>> Perempuan<br>
    Email: <input type="text" name="email" value="<?= $edit ? $row['email'] : '' ?>"><br>
    Alamat: <textarea name="alamat"><?= $edit ? $row['alamat'] : '' ?></textarea><br>
    <button type="submit" name="proses" value="<?= $edit ? 'Update' : 'Simpan' ?>"><?= $edit ? 'Update' : 'Simpan' ?></button>
    <button type="submit" name="proses" value="Batal">Batal</button>
</form>
